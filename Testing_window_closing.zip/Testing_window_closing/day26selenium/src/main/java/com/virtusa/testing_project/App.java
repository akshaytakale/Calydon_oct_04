package com.virtusa.testing_project;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	 System.setProperty("webdriver.chrome.driver","D:\\JP\\Chrome_Driver\\chromedriver.exe");//Enter Chrome driver path here
         System.out.println( "Hello World!" );
         
         WebDriver webDriver=new ChromeDriver();//we are using chrome browser to run test cases
         
          webDriver.get("https://www.hackerrank.com/");
         webDriver.manage().window().maximize();
         webDriver.findElement(By.xpath("//*[@id=\"post-71\"]/div/div/div[1]/div/div/div/div/div/div[2]/div/div/a/span")).click();
       
         webDriver.manage().window().maximize();
         webDriver.findElement(By.xpath("//*[@id=\"content\"]/div/div/div[3]/div[2]/div/div/div[2]/div/div/div[2]/div[2]/ul/li[2]/a/img")).click();
        
         //webDriver.findElement(By.name("identifier")).sendKeys("abc.gmail.com");
         
         String mainWindow=webDriver.getWindowHandle();
         
         //to handle all new opened window
         Set<String> childWindows=webDriver.getWindowHandles();
         Iterator<String> itr=childWindows.iterator();
         
       
         while(itr.hasNext())
         {
        	 String ChildWindow=itr.next();
        	 if(!mainWindow.equalsIgnoreCase(ChildWindow))
        	 {
        		 webDriver.switchTo().window(ChildWindow);
        		 webDriver.findElement(By.xpath("//*[@id=\"identifierId\"]")).sendKeys("abc.gmail.com");
        		 
        		 try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        		 //closing child window
        		 webDriver.close();
        	  }
         }
         //switching to parent window
         webDriver.switchTo().window(mainWindow);
         
    }
}
