package com.virtusa.shopping.models;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;


@Entity
@Table(name="Day14Product")
public class Product {
 
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Product_Id")
	private int productId;
	@Column(name = "Product_Name",nullable = false,length = 50)
	private String productName;
	@Column(name = "Cost")
	private int cost;
	@DateTimeFormat(iso = ISO.DATE)
	//@JsonFormat(pattern="yyyy-MMM-dd",shape=Shape.STRING)
	@Column(name = "Date_of_Purchase")
	private LocalDate dop;	
	@ManyToOne(cascade = CascadeType.MERGE,fetch = FetchType.LAZY)
	@JoinColumn(name = "Category_Id")
	private Category category;	
	
	
	
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public LocalDate getDop() {
		return dop;
	}
	public void setDop(LocalDate dop) {
		this.dop = dop;
	}
	
	
	
	
	
	
}
