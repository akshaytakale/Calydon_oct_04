package com.virtusa.shopping.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.virtusa.shopping.models.Category;
import com.virtusa.shopping.models.Product;
import com.virtusa.shopping.services.CategoryService;
import com.virtusa.shopping.services.ProductService;

@Controller
public class PoductController {
	
	@Autowired
	private CategoryService categoryService;
	@Autowired
	private ProductService productService;
	@ModelAttribute("categories")
	public List<Category> getAllCategories()
	{
		
		return categoryService.getAllCategories();
		
	}
	
	@GetMapping("/addproduct")
	public String addProduct()
	{
		return "addproduct";
	}
	
	@PostMapping("/saveproduct")
	public String saveProduct(@ModelAttribute Product product,@RequestParam String categoryInfo, Model model)
	{
		String[] data=categoryInfo.split("-");
		System.out.println(data[0]);
		int categoryId= Integer.parseInt(data[0]);
		model.addAttribute("product", productService.saveProduct(product, categoryId));
		return "addproduct";
		
	}

}
