package com.virtusa.shopping.repositaries;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.shopping.models.Category;

public interface CategoryRepositary extends JpaRepository<Category,Integer>{

}
