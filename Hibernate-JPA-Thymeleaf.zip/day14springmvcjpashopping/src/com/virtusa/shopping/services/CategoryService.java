package com.virtusa.shopping.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.shopping.models.Category;
import com.virtusa.shopping.repositaries.CategoryRepositary;

@Service
public class CategoryService {
	@Autowired
	private CategoryRepositary categoryRepo;
	
	public Category saveCategory(Category category)
	{
		 return categoryRepo.save(category);
	}
	
	public List<Category> getAllCategories()
	{
		return categoryRepo.findAll();
		
	}
	
	public Category getCategotyById(int categoryId)
	{
		return categoryRepo.findById(categoryId).orElse(null);
	}


}
