package com.virtusa.springbootmvc.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.springbootmvc.models.Customer;
import com.virtusa.springbootmvc.services.CustomerService;


@RestController
public class CustomerController
{
	@Autowired
	private CustomerService customerService;
	
	@CrossOrigin("*")
	@PostMapping("/addcustomer")
	public @ResponseBody Customer addCustomer(@RequestBody Customer customer)
	{
		return customerService.saveCustomer(customer);
		
	}
	
	@CrossOrigin("*")
	@GetMapping("/getcustomers")
	public List<Customer> findAllCustomer()
	{
		return customerService.getAllCustomer();
	}
	
	@CrossOrigin("*")
	@GetMapping("/getcustomerbyid/{customerId}")
	public Customer FindByCustomerId(@PathVariable("customerId") int customerId)
	{
		return customerService.getCustomerById(customerId);
		
	}
	
	
	
}
