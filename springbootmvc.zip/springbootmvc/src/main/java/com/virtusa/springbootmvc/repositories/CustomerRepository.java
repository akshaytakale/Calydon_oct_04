package com.virtusa.springbootmvc.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.springbootmvc.models.Customer;

public interface CustomerRepository extends JpaRepository<Customer,Integer>
{

}
