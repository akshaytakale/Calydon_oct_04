$(document).ready(function () {
    alert("Ready");

    $("#customerForm").submit(function () {
        alert("Submitted");

        //read all the values from form
        var customerName=$("#customerName").val();
        var password=$("#password").val();
        var dob=$("#dob").val();
        console.log(customerName+","+password+","+dob);

        //create json object
        var customer={
                    "customerName":customerName,
                    "password":password,
                    "dob":dob

        }

        //stringify
        customer=JSON.stringify(customer);
        console.log(customer);

        //call Ajax
        $.ajax({
            url:"http://localhost:7070/springjparestdemo/addcustomer",
            type:'POST',
            contentType:'application/json',
            data:customer,
            dataType:'json',
            success:function(data)
            {
                console.log(data);
                $("<h4>").text("Customer Added succesfully id="+data.customerId).appendTo("#section");
            },
            failure:function(err)
            {
                console.log(err);
            }

        });
    });
})