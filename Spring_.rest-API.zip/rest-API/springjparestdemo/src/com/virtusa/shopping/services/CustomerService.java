package com.virtusa.shopping.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.shopping.models.Customer;
import com.virtusa.shopping.repository.CustomerRepository;

@Service
public class CustomerService 
{
	@Autowired
	private CustomerRepository customerRepository;
	
	public Customer saveCustomer(Customer customer)
	{
		return customerRepository.save(customer);
		
	}
	
	 public Customer getCustomerById(int id)
		{
			return customerRepository.findById(id).orElse(null);
		}
	 
	public List<Customer> getAllCustomer()
	{
		// TODO Auto-generated method stub
		return customerRepository.findAll();
	}
}

