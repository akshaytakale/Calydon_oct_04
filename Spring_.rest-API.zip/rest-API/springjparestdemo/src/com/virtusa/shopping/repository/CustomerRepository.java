package com.virtusa.shopping.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.shopping.models.Customer;

public interface CustomerRepository extends JpaRepository<Customer,Integer>
{

}
